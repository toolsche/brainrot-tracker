import BrainrotIndex from './components/BrainrotIndex';

function App() {
  return (
    <div className="min-h-screen bg-zinc-900 text-white">
      {/* Hier kannst du später noch eine Navbar einbauen */}
      <BrainrotIndex />
    </div>
  );
}

export default App;